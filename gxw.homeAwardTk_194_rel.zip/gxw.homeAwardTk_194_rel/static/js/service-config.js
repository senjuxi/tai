var __wxConfig__ = {
	"debug": true,
	"babel": true,
	"appname": "我的奖品",
	"window": {
		"backPressEnable": true,
		"showNavigationBar": false,
		"pages": {
			"index": {
				"navigationBarTitleText": "我的奖品",
				"enablePullDownRefresh": false
			}
		}
	},
	"pages": ["index"],
	"root": "index",
}